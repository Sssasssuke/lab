import os
import zipfile
import argparse
import secrets
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

# маркер для разделения файла и подписи
SEPARATOR = b'\x42\x42\x42\x53\x49\x47\x42\x42\x42'


def make_keys():
    print("Создание ключей отправителя...")
    sender_private = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    sender_public = sender_private.public_key()
    
    print("Создание ключей получателя...")
    receiver_private = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    receiver_public = receiver_private.public_key()
    
    with open("sender_secret.pem", "wb") as f:
        f.write(sender_private.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        ))
    
    with open("sender_open.pem", "wb") as f:
        f.write(sender_public.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ))
    
    with open("receiver_secret.pem", "wb") as f:
        f.write(receiver_private.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        ))
    
    with open("receiver_open.pem", "wb") as f:
        f.write(receiver_public.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ))
    
    print("\n[ГОТОВО] Созданы файлы ключей:")
    print("  sender_secret.pem ")
    print("  sender_open.pem ")
    print("  receiver_secret.pem ")
    print("  receiver_open.pem ")


def get_key(filename, personal=False):
    with open(filename, "rb") as file:
        key_content = file.read()
    if personal:
        return serialization.load_pem_private_key(key_content, password=None, backend=default_backend())
    else:
        return serialization.load_pem_public_key(key_content, backend=default_backend())


def calc_signature(content, private_key):
    signature = private_key.sign(
        content,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    return signature


def check_signature(content, signature, public_key):
    try:
        public_key.verify(
            signature,
            content,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        return True
    except:
        return False


def aes_code(data, session_key):
    init_vector = secrets.token_bytes(16)
    cipher_instance = Cipher(algorithms.AES(session_key), modes.CFB(init_vector), backend=default_backend())
    encoder = cipher_instance.encryptor()
    result = encoder.update(data) + encoder.finalize()
    return init_vector + result


def aes_decode(encrypted_data, session_key):
    init_vector = encrypted_data[:16]
    text_part = encrypted_data[16:]
    cipher_instance = Cipher(algorithms.AES(session_key), modes.CFB(init_vector), backend=default_backend())
    decoder = cipher_instance.decryptor()
    return decoder.update(text_part) + decoder.finalize()


def transmit_file(source_path):
    if not os.path.exists(source_path):
        print(f"[ОШИБКА] Файл {source_path} отсутствует")
        return
    
    print(f"\n>> ОТПРАВКА: {source_path}")
    
    if not os.path.exists("sender_secret.pem"):
        print("Нет sender_secret.pem! Запустите --genkeys")
        return
    if not os.path.exists("receiver_open.pem"):
        print("Нет receiver_open.pem (нужен публичный ключ получателя)")
        return
    
    print(">> Загрузка ключей...")
    my_private_key = get_key("sender_secret.pem", personal=True)
    receiver_public_key = get_key("receiver_open.pem", personal=False)
    
    with open(source_path, "rb") as file:
        original_bytes = file.read()
    print(f"   Исходный размер: {len(original_bytes)} байт")
    
    print(">> Создание ЭЦП...")
    digital_sign = calc_signature(original_bytes, my_private_key)
    print(f"   Длина подписи: {len(digital_sign)} байт")
    
    combined_data = original_bytes + SEPARATOR + digital_sign
    print(f"   Блок для шифрования: {len(combined_data)} байт")
    
    print(">> AES-шифрование...")
    session_key = secrets.token_bytes(32)
    encrypted_block = aes_code(combined_data, session_key)
    print(f"   После AES: {len(encrypted_block)} байт")
    
    print(">> RSA-шифрование сеансового ключа...")
    encrypted_session_key = receiver_public_key.encrypt(
        session_key,
        padding.OAEP(
            mgf=padding.MGF1(hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    print(f"   Зашифрованный ключ: {len(encrypted_session_key)} байт")
    
    print(">> Создание ZIP-архива...")
    with zipfile.ZipFile("transfer_package.zip", "w") as zip_file:
        zip_file.writestr("secret_key.bin", encrypted_session_key)
        zip_file.writestr("secret_data.bin", encrypted_block)
    
    print("\n[ГОТОВО] Создан архив: transfer_package.zip")


def obtain_file():
    if not os.path.exists("transfer_package.zip"):
        print("[ОШИБКА] transfer_package.zip не найден")
        return
    
    print("\n>> ПОЛУЧЕНИЕ ФАЙЛА")
    
    if not os.path.exists("receiver_secret.pem"):
        print("Нет receiver_secret.pem (ваш личный ключ)!")
        return
    if not os.path.exists("sender_open.pem"):
        print("Нет sender_open.pem (публичный ключ отправителя)!")
        return
    
    print(">> Загрузка ключей...")
    my_private_key = get_key("receiver_secret.pem", personal=True)
    sender_public_key = get_key("sender_open.pem", personal=False)
    
    print(">> Распаковка архива...")
    with zipfile.ZipFile("transfer_package.zip", "r") as zip_file:
        encrypted_key_data = zip_file.read("secret_key.bin")
        encrypted_content_data = zip_file.read("secret_data.bin")
    print(f"   secret_key.bin: {len(encrypted_key_data)} байт")
    print(f"   secret_data.bin: {len(encrypted_content_data)} байт")
    
    print(">> Расшифровка сеансового ключа...")
    try:
        session_key = my_private_key.decrypt(
            encrypted_key_data,
            padding.OAEP(
                mgf=padding.MGF1(hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        print(f"   Ключ восстановлен: {len(session_key)} байт")
    except Exception as error:
        print(f"[ОШИБКА] Не удалось расшифровать ключ: {error}")
        return
    
    print(">> Расшифровка данных...")
    try:
        combined_bytes = aes_decode(encrypted_content_data, session_key)
        print(f"   Расшифровано: {len(combined_bytes)} байт")
    except Exception as error:
        print(f"[ОШИБКА] Ошибка расшифровки: {error}")
        return
    
    if SEPARATOR not in combined_bytes:
        print("[ОШИБКА] Маркер разделения отсутствует")
        return
    
    original_part, signature_part = combined_bytes.split(SEPARATOR, 1)
    print(f">> Разделение: файл ({len(original_part)} байт), подпись ({len(signature_part)} байт)")
    
    print(">> Проверка подписи...")
    if check_signature(original_part, signature_part, sender_public_key):
        print("   [УСПЕХ] ПОДЛИННОСТЬ ПОДТВЕРЖДЕНА!")
        
        output_filename = "restored_output.txt"
        with open(output_filename, "wb") as file:
            file.write(original_part)
        print(f"\n[ГОТОВО] Результат сохранён: {output_filename}")
    else:
        print("   [ОШИБКА] ПОДЛИННОСТЬ НЕ ПОДТВЕРЖДЕНА!")


def main():
    parser = argparse.ArgumentParser(description="Программа защищённой передачи файлов")
    parser.add_argument("--genkeys", action="store_true", help="Создать ключи")
    parser.add_argument("--send", metavar="FILE", help="Передать файл")
    parser.add_argument("--receive", action="store_true", help="Принять файл")
    
    arguments = parser.parse_args()
    
    if arguments.genkeys:
        make_keys()
    elif arguments.send:
        transmit_file(arguments.send)
    elif arguments.receive:
        obtain_file()
    else:
        print("Инструкция по использованию:")
        print("  python secure_crypto.py --genkeys")
        print("  python secure_crypto.py --send document.txt")
        print("  python secure_crypto.py --receive")

if __name__ == "__main__":
    main()