import zipfile
import os

print("ТЕСТ: Попытка модификации зашифрованных данных")

if not os.path.exists("transfer_package.zip"):
    print("Сначала выполните: python secure_crypto.py --send message.txt")
    exit()

# Читаем содержимое архива
with zipfile.ZipFile("transfer_package.zip", "r") as archive:
    key_content = archive.read("secret_key.bin")
    data_content = archive.read("secret_data.bin")

# Изменяем один байт в зашифрованных данных
data_list = list(data_content)
data_list[77] = data_list[77] ^ 0xFF
modified_data = bytes(data_list)

# Создаём архив с изменёнными данными
with zipfile.ZipFile("transfer_package.zip", "w") as archive:
    archive.writestr("secret_key.bin", key_content)
    archive.writestr("secret_data.bin", modified_data)

print("[ИЗМЕНЕНО] secret_data.bin модифицирован (77-й байт инвертирован)")
print("Пробуем восстановить файл...")
print("-" * 50)

os.system("python secure_crypto.py --receive")