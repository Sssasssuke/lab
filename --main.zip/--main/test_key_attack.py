import zipfile
import os

print("ТЕСТ: Модификация зашифрованного ключа (secret_key.bin)")

if not os.path.exists("transfer_package.zip"):
    print("Сначала выполните: python secure_crypto.py --send message.txt")
    exit()

# Читаем содержимое архива
with zipfile.ZipFile("transfer_package.zip", "r") as archive:
    key_content = archive.read("secret_key.bin")
    data_content = archive.read("secret_data.bin")

# Изменяем 50-й байт в зашифрованном ключе
key_list = list(key_content)
key_list[50] = (key_list[50] + 1) % 256  # увеличиваем на 1
modified_key = bytes(key_list)

# Создаём архив с изменённым ключом
with zipfile.ZipFile("transfer_package.zip", "w") as archive:
    archive.writestr("secret_key.bin", modified_key)
    archive.writestr("secret_data.bin", data_content)

print("[ИЗМЕНЕНО] secret_key.bin модифицирован (50-й байт увеличен на 1)")
print("Пробуем расшифровать...")
print("-" * 50)

os.system("python secure_crypto.py --receive")